#pragma once

#include <QCheckBox>

class MuteCheckBox : public QCheckBox {
	Q_OBJECT
};
